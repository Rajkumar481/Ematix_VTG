import React from 'react'

const patientImages = () => {
  return (
    <div>
      <h1>hello</h1>
    </div>
  )
}

export default patientImages
